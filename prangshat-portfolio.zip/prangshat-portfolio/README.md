# Prangshat Khamwiset — Product Designer Portfolio

A dark-mode product-design portfolio built as a single self-contained React
component, scaffolded with **Vite**. Includes two case studies (Easy Smart
ecosystem and MyMo by GSB) with Apple-style device showcases, scroll-driven
motion, and embedded real product screenshots.

## Requirements

- [Node.js](https://nodejs.org/) **18+** (LTS recommended)
- npm (ships with Node)

## Getting started

```bash
# 1. install dependencies
npm install

# 2. start the dev server (http://localhost:5173)
npm run dev

# 3. build for production (outputs to /dist)
npm run build

# 4. preview the production build locally
npm run preview
```

## Project structure

```
prangshat-portfolio/
├── index.html              # HTML entry; mounts #root
├── package.json
├── vite.config.js          # Vite + @vitejs/plugin-react
├── public/
│   └── Resume_Prangshat.pdf # served at /Resume_Prangshat.pdf (Download Résumé button)
└── src/
    ├── main.jsx            # React entry — renders <Portfolio />
    ├── index.css           # minimal reset only
    └── Portfolio.jsx       # the entire site (component, styles, images)
```

## Notes

- **Everything lives in `src/Portfolio.jsx`.** It injects its own stylesheet
  (design tokens, typography, layout, animations) scoped to a `.pf-root`
  wrapper, and loads its fonts (Inter, Inter Tight, JetBrains Mono) via a
  Google Fonts `@import`. `src/index.css` is intentionally just a reset.
- **Images are embedded** as base64 data URIs inside the component, so the
  build has no external image dependencies. This makes `Portfolio.jsx` large
  (~1.1 MB); that is expected.
- **Résumé:** the “Download Résumé” button links to `Resume_Prangshat.pdf`,
  served from `public/`. Replace that file to update the download.
- **LinkedIn** on the Contact section is a placeholder
  (`linkedin.com/in/prangshat-khamwiset`) — update it in `Portfolio.jsx`
  (`PROFILE.linkedin`) with the real URL.

## Editing content

Open `src/Portfolio.jsx` and look for:

- `PROFILE` — name, contact details, résumé/LinkedIn links
- `STATS` — the hero stat row
- `CASE_STUDIES` — case-study copy, tags, and metadata
- `CASE_MEDIA` — the embedded screenshot data URIs
- `--mymo-shot-h` (in the injected CSS) — the single shared height for all
  static MyMo case-study screenshots

## License

Personal portfolio content © Prangshat Khamwiset. Code provided for personal
use and adaptation.
